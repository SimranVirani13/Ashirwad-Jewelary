<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Mahurat Login</title>
    <link rel="stylesheet" href="new.css">
    <link href="https://fonts.googleapis.com/css2?family=Kaushan+Script&display=swap" rel="stylesheet">
</head>
<body>
    <div class="full-page">
        <div class="sub-page">
            <div class="navigation-bar">
                <div class="logo">
                    <a href='photography.html'> <img src="images/logo/logo.jpg"></a> 
                </div>
				<style>
				   body{
				   background-image:
				   url('1.jpg')
						}
				
				</style>
                <nav>
                    <ul id='MenuItems'>
                        <li><a href='name.php'>Home</a></li> 
                        <li><a href='name.php'>Photos</a></li>
                        <li><a href='name.php'>Services</a></li>
                        <li><a href='#'>Contact</a></li>
                    </ul>
                </nav>
            </div>
            <div class="row">
                <div class="col-1">
                    <div class="form-box">
                        <div class="form">
                            <form class="login-form">
                                <center><h1 class="main-heading">Login Form</h1></center>
                    <input type="text"placeholder="user name"/>
                    <input type="password"placeholder="password"/>
                    <button><a href='name.php'>LOGIN</a></button>
                    <p class="message">Not Registered? <a href="#">Register</a></p>
                </form>
                            <form class="register-form">
                                <center><h1 class="main-heading">Register Form</h1></center>
                    <input type="text" placeholder="user name"/>
                    <input type="text" placeholder="email-id"/>
                    <input type="password" placeholder="password"/>
                    <button>REGISTER</button>
                    <p class="message">Already Registered?<a href="#">Login</a>
                    </p>
                </form>
                </div>
                 </div>
                </div>
                <div class="col-1">
				<p class='defination'><br></p>
                </div>
            </div>
        </div>
    </div>
    <script src='https://code.jquery.com/jquery-3.2.1.min.js'>
    </script>
    <script>
        $('.message a').click(function(){$('form').animate({height: "toggle",opacity: "toggle"},"slow");});
    </script>
</body>
</html>
